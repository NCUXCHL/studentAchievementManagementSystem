#include <stdio.h>
#include "student.h"
int readScore(STU *stu)
{
    int i=0;
    FILE* fp;
    fp=fopen("data/studentMessage.txt","r");
	printf("1\n");
    while(1)
    {
        fscanf(fp,"%I64d %s %d %d %d %d %d %f\n",&stu[i].number,stu[i].name,&stu[i].score[0],&stu[i].score[1],&stu[i].score[2],&stu[i].score[3],&stu[i].sum,&stu[i].average);
        //printf("%I64d %s %d %d %d %d %d %f\n",stu[i].number,stu[i].name,stu[i].score[0],stu[i].score[1],stu[i].score[2],stu[i].score[3],stu[i].sum,stu[i].average);
        i++;
        if(feof(fp))break;
    }
    return i;
}

