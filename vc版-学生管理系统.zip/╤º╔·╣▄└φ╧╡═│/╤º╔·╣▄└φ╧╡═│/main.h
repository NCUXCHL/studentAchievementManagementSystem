#ifndef _H_main_H_
#define _H_main_H_

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include<conio.h>
#include<string.h>

#endif

