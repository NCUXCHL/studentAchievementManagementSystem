#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED

char menuTeacher(void);
char menuStudent(void);

#endif // MENU_H_INCLUDED

