#ifndef DETERMINEUSERLDENTITY_H_INCLUDED
#define DETERMINEUSERLDENTITY_H_INCLUDED



int DetermineUserLdentity(char *ID, char *password, char (*Tid)[11],char(*Tspw)[11],char (*Sid)[11],char (*Spsw)[11]);
void ReadTfile(char (*Tid)[11],char (*Tpsw)[11]);
void ReadSfile(char (*Sid)[11],char (*Spsw)[11]);

#endif // DETERMINEUSERLDENTITY_H_INCLUDED

