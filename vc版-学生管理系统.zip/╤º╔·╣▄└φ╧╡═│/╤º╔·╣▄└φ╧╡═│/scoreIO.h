#ifndef _H_scoreio_H_
#define _H_scoreio_H_

void appendScore(STU *head, int n, int m,int f);
void printScore(STU *head, int n, int m);

#endif

