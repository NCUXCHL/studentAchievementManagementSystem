#ifndef _H_search_H_
#define _H_search_H_

int searchNum(STU *head, int num, int n);
void searchScore(STU *head, int n, int m);

#endif

