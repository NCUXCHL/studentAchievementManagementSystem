#include<stdio.h>
#include "student.h"
void deleteScore (STU *stu,int n)
{
    int i;
    int d;
    int ret=0;
    printf("if you don`t want to delete data ,you can input '0' to back menu)\n");
    printf("Intput Deleted ID:(0<n<=%d)\n",n);
    ret=scanf("%d",&d);
    while(ret!=1||d<=0||d>n)
    {
        fflush(stdin);
        if(ret!=1)
        {
            printf("input error!!!\n");
        }
        else if(d==0)
        {
            return 0;
        }
        else
        {
            printf("NOT FOUND!!!\n");
        }
        printf("if you don`t want to delete data ,you can input '0' to back menu)\n");
        printf("Please enter a number(0<n<=%d)\n",n);
        ret=scanf("%d",&d);
    }
    for(i=d-1;i<n-1; i++)
    {
        stu[i]=stu[i+1];
    }
}
void editScore(STU* stu, int n, int m)
{
    int e;
    int i;
    int ret;
    printf("if you don`t want to delete data ,you can input '0' to back menu)\n");
    printf("Input Edited ID:(0<n<=%d)\n",n);
    ret=scanf("%d",&e);
    while(ret!=1||(0>=e)||(e>n))
    {
        fflush(stdin);
        if(ret!=1)
        {
            printf("input error!!!\n");
        }
        else if(e==0)
        {
            return 0;
        }
        else
        {
            printf("NOT FOUND!!!\n");
        }
        printf("if you don`t want to delete data ,you can input '0' to back menu)\n");
        printf("Please enter a number(0<n<=%d)\n",n);
    ret=scanf("%d",&e);
    }
    e=e-1;
    printf("number:"); scanf("%I64d",&stu[e].number);
    printf("edited name:");scanf("%s",stu[e].name);
    stu[e].sum=0;
    for(i=0;i<m;i++)
    {
        printf("edited score%d:",i+1);scanf("%d",&stu[e].score[i]);
        stu[e].sum+=stu[e].score[i];
    }
    stu[e].average=(float)stu[e].sum/m;

}
void saveScore(STU* stu, STU* istu, int n, int m)
{

    int i,j;
    FILE* fp=NULL;
    fp=fopen("data/studentMessage.txt","w");
    for(i=0;i<n;i++)
    {
        fprintf(fp,"%I64d ",stu[i].number);
        fprintf(fp,"%s ",stu[i].name);
        for(j=0;j<m;j++)
        {
            fprintf(fp,"%d ",stu[i].score[j]);
        }
        fprintf(fp,"%d ",stu[i].sum);
        fprintf(fp,"%.2f",stu[i].average);
        fprintf(fp,"\n");
    }
     memcpy(istu,stu,sizeof(STU)*STU_NUM);                             //����

    printf("----------save successd! ! !------------\n");
}

