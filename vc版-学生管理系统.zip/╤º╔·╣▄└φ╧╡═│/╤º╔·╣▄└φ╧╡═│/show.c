#include "student.h"
void temp_prove(int ch){
    if(ch==1)
    {
        printf("�㵱ǰ�ǽ�ʦģʽ���������Ȩ��:\n");
    }
	else
    {
        printf("�㵱ǰ��ѧ��ģʽ���������Ȩ��:\n");
    }
	printf("------------------------------------------------------\n");
}
int compareArray(STU* stu,STU *istu,int n)
{
    int i;
    for(i=0; i<n;i++)
    {
        if(stu[i].number != istu[i].number)
        {
            return 1;
        }
    }
    return 0;
}
int savedata( void)
{
    char c;
    system("cls");
        printf("---------------------------------------------------------\n");
        printf("you don`t save data\n");
        printf("-------------------------------------------------------------\n");
        printf("you can input 's' to save data,input others to end of program directly\n");
        scanf(" %c", &c);
        if(c=='s')
        {
            return 1;
        }
        else{
            return 0;
        }
}




