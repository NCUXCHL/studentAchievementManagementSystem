/***********************************************************************
* �� �� ����main.c
* ��Ҫ���ܣ��������ļ������ø�����ģ�麯��
* ��ע��
************************************************************************/

#include "main.h"
#include "menu.h"
#include "student.h"
#include "search.h"
#include "scoreIO.h"
#include "help.h"
#include "DetermineUserLdentity.h"


int main()
{
    int flat=1;
    int d;
    int f;
    int k=0;
	char ch;
	int  n=0;
	int m=4;
	STU stu[STU_NUM];
	STU istu[STU_NUM];
	char ID[11];
	char password[11];
    char Tid[30][11]={'\0'};                                            //�洢��ʦ�û���
	char Tpsw[30][11]={'\0'};                                 //�洢��ʦ������
	char Sid[30][11]={'\0'};                                               //�洢ѧ���û���
	char Spsw[30][11]={'\0'};                                 //�洢ѧ���û���
	memset(stu, 0, sizeof(stu));                                          //�Խṹ��������г�ʼ��
																			//�ļ�һ��ʼ��ѧ������
	memset(istu, 0, sizeof(istu));

	system("title ѧ���ɼ�����ϵͳ��Student Achievement Management System��");  //�޸ĳ������
	system("mode con cols=80 lines=20");                                                                            //�޸ĳ��򳤿�
	system("color B8");                                                                                                              //�޸���ɫ
	system("TIME/T");                                                                                                               //����ʱ��
	system("date /T");  //��������


	ReadTfile(Tid,Tpsw);
	ReadSfile(Sid,Spsw);
	f=readScore(stu);
    memcpy(istu,stu,sizeof(STU)*f);
    //printScore(istu, STU_NUM, 4);
    n=f;
    do{
			flat=1;
            d=DetermineUserLdentity(ID, password, Tid, Tpsw, Sid,Spsw);    /* �ж��û������ݣ��ǽ�ʦ����ѧ����ҳ�*/

            if(d==1)
            {

                copyright();                                                 /*һ����ӭ�����������Ϣ�Ľ���*/


                while (flat!=-1)
                {
                    ch = menuTeacher();				    /* ��ʾ�˵�������ȡ�û����� */
                    switch (ch)
                    {
                        case'1':
                            system("CLS");//����
                            system("color A0");
                            temp_prove(d);

                            printf("Input student number (0<=n<=%d):\n", STU_NUM-n);
                            scanf("%d",&n);
                            n=n+f;
                            printf("Input course number(0<m<10):\n4\n");

                            appendScore(stu, n-f, m,f); /* ���óɼ�����ģ�� */
                            totalScore(stu, n, m);
                            system("pause");         //system("pause")����ʵ�ֶ�����Ļ��
                            break;
                        case'2':
                            system("CLS");
                            system("color 70");
                            temp_prove(d);
                            printScore(stu, n, m);  /* ���óɼ���ʾģ�� */
                            system("pause");         //system("pause")����ʵ�ֶ�����Ļ��
                            break;
                        case'3':
                            system("CLS");
                            system("color A8");
                            temp_prove(d);
                            searchScore(stu, n, m); /* ���ð�ѧ�Ų���ģ�� */
                            system("pause");         //system("pause")����ʵ�ֶ�����Ļ��
                            break;
                        case'4':
                            system("CLS");
                            system("color 50");
                            temp_prove(d);
                            printScore(stu, n, m );	/* ��ʾ�ɼ������� */
                             deleteScore(stu, n);
                             n--;                                           /*���óɼ�ɾ��ģ��*/
                                break;
                        case'5':
                            system("CLS");
                            system("color 80");
                            temp_prove(d);
                                printScore(stu, n, m );	/* ��ʾ�ɼ������� */
                               editScore(stu,n,m);                                         /*���óɼ��༭ģ��*/
                                break;

                        case'6':
                             system("CLS");
                            system("color A0");
                            temp_prove(d);
                            while(sortScore(stu, n,m))      /* ���óɼ�����ģ�� */
                            {
                                printf("\nSorted result\n");
                                printScore(stu, n, m );	/* ��ʾ�ɼ������� */
                                system("pause");         //system("pause")����ʵ�ֶ�����Ļ��
                            }
                            break;
                        case'7':
                             system("CLS");
                            system("color A0");
                            temp_prove(d);
                            printScore(stu, n, m);                /*���óɼ�����ģ��*/
                              saveScore(stu, istu, n, m);
                              system("pause");
                            break;
                        case'8':
                            help();					/* ���ð�����Ϣ */
                            helpMenuChoose();
                            break;
                        case'9':
                            system("cls");
                            flat=-1;
                            break;                  /*�л�ģʽ*/
                        case'0':
                            if(compareArray(stu, istu,n))
                            {

                                    if(savedata())
                                    {
                                        saveScore(stu,istu,n,m);
                                        system("pause");
                                    }
                            }
                                exit(0);                /* �˳����� */
                                printf("End of program!");
                                break;
                        default:
                            printf("Input error!");
                            break;
                    }
            }
            }else if(d==2)
            {
                n=f;
                while(flat!=-1)
                {
                    ch = menuStudent();				    /* ��ʾ�˵�������ȡ�û����� */

                    switch (ch)
                    {
                        case'1':
                             system("CLS");
                            system("color 70");
                            temp_prove(d);
                            printScore(stu, n, m);  /* ���óɼ���ʾģ�� */
                            system("pause");         //system("pause")����ʵ�ֶ�����Ļ��
                            break;
                        case'2':
                             system("CLS");
                            system("color 90");
                            temp_prove(d);
                            searchScore(stu, n, m); /* ���ð�ѧ�Ų���ģ�� */
                            system("pause");         //system("pause")����ʵ�ֶ�����Ļ��
                            break;
                        case'3':
                            system("CLS");
                            system("color A0");
                            temp_prove(d);
                            while(sortScore(stu, n,m))      /* ���óɼ�����ģ�� */
                            {
                                printf("\nSorted result\n");
                                printScore(stu, n, m );	/* ��ʾ�ɼ������� */
                                system("pause");         //system("pause")����ʵ�ֶ�����Ļ��
                            }
                            break;
                        case'4':
                            system("CLS");
                            system("color 90");
                            temp_prove(d);
                            printScore(stu, n, m);
                            saveScore(stu,istu,n,m);
                              system("pause");                                      /*���óɼ�����ģ��*/
                            break;
                        case'5':
                            help();					/* ���ð�����Ϣ */
                            helpMenuChoose();
                            break;
                        case'6':
                            system("cls");
                            flat = -1;
                            break;
                        case'0':
                            if(compareArray(stu, istu,n))
                            {

                                    if(savedata())
                                    {
                                        saveScore(stu,istu,n,m);
                                        system("pause");
                                    }
                            }
                                exit(0);                /* �˳����� */
                                printf("End of program!");
                                break;
                        default:
                            printf("Input error!");
                            break;
                    }
                  }
            }else if(d==0)
            {
                flat=0;
            }
    }while(flat);
	return 0;
    }

